package com.example.tarea10

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private var contador_total = 0
    private var minimo = 0   // Valor mínimo predeterminado

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sumaClick = findViewById<Button>(R.id.btnMas)
        val restaClick = findViewById<Button>(R.id.btnMenos)

        val maxEditText = findViewById<EditText>(R.id.etMax)
        val minEditText = findViewById<EditText>(R.id.etMin)

        val vistaNumero = findViewById<TextView>(R.id.tvNumero)

        // el Listener para detectar cambios en el valor mínimo
        minEditText.setOnFocusChangeListener { _, _ ->
            minimo = minEditText.text.toString().toIntOrNull() ?: minimo
        }

        // Listener para el botón de suma
        sumaClick.setOnClickListener {
            try {
                val max = maxEditText.text.toString().toInt()
                if (contador_total < max) {
                    contador_total += 1
                    vistaNumero.text = contador_total.toString()
                } else {
                    Toast.makeText(this, "Se alcanzó el valor máximo", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                // Manejo de excepciones al sumar
                Log.e("MainActivity", "Error al sumar: ${e.message}")
                Toast.makeText(this, "Error al sumar", Toast.LENGTH_SHORT).show()
            }
        }

        // Listener para el botón de resta
        restaClick.setOnClickListener {
            try {
                if (contador_total > minimo) {
                    contador_total -= 1
                    vistaNumero.text = contador_total.toString()
                } else {
                    Toast.makeText(this, "Se alcanzó el valor mínimo", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error al restar: ${e.message}")
                Toast.makeText(this, "Error al restar", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
